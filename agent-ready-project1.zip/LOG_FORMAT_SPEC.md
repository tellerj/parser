# Operator Log Format Specification

Source: `Project 1 - Mission Logging SOP (CAO 20250611) --signed.pdf`

This document defines the exact text format of 57 IAS operator mission logs (`.msn` files). A parser must handle each section described below.

---

## Global Formatting Rules

- **Indentation**: Spaces only, NO tabs. Each indent level = 4 spaces.
  - Level 0: 0 spaces (mission metadata, scheme of maneuver, log body header, host headers, artifact headers)
  - Level 1: 4 spaces (tool headers)
  - Level 2: 8 spaces (command input lines)
  - Level 3: 12 spaces (command output lines)
- **Timezone**: All timestamps are in ZULU (UTC).
- **File extension**: `.msn` (plain text)
- **File naming**: `YYYYMMDD <Operator>.msn` (e.g., `20250610 Slade.msn`)
- **No callsigns**: Real last names only, no tactical callsigns in logs.

---

## Section 1: Mission Metadata

**Indent level**: 0

```
MSN Name: <short_mission_name>
MSN Date: <YYYY-MM-DD>
Operator(s): <LastName1>, <LastName2>
```

### Fields
| Field | Format | Description |
|-------|--------|-------------|
| `MSN Name` | String, no spaces | Short identifier for the mission |
| `MSN Date` | `YYYY-MM-DD` | ZULU date of mission |
| `Operator(s)` | Comma-separated last names | Must match across all log references |

### Parser regex
```
^MSN Name: (.+)$
^MSN Date: (\d{4}-\d{2}-\d{2})$
^Operator\(s\): (.+)$
```

---

## Section 2: Scheme of Maneuver

**Indent level**: 0

### Header
```
Scheme Of Maneuver
```

### Entry format
```
<maneuver_level> <ip_address> <fqdn> <network_tech> <os> <status> [comments...]
```

### Fields
| Field | Description | Constraints |
|-------|-------------|-------------|
| `maneuver_level` | Dash-arrow chain showing pivot depth | Starts with `->`, each additional `-` = one more pivot level |
| `ip_address` | IPv4 or IPv6 address | No spaces |
| `fqdn` | Fully qualified domain name | No spaces |
| `network_tech` | Network technology / beacon type | e.g., `RTP`, `IPTables`, `Beacon(HTTPS)`, `Beacon(SMB)`, `SSH`, `RDP` |
| `os` | Operating system | e.g., `linux`, `unix`, `windows` |
| `status` | Success/failure | `success` or `fail` |
| `comments` | Optional free text | Only field that allows spaces; rest of line after status |

### Maneuver level rules
- `->` = Level 1 (direct access from Red infrastructure)
- `-->` = Level 2 (pivoted through one hop)
- `--->` = Level 3 (pivoted through two hops)
- Adding a dash increases pivot depth (attacker pivots *through* the previous target)
- Removing a dash decreases pivot depth (back to a previous pivot point)

### Example
```
Scheme Of Maneuver
-> 10.0.15.25 rtp1-team4.batcave.local RTP linux success
--> 98.76.34.155 globalsuppplycatalog.com IPTables unix success
--> 154.67.23.88 winchesterfurniturellc.com IPTables unix success
--> 40.34.240.53 cdn.arenanetworks.com IPTables unix success
---> 192.168.12.110 ws2.whatta.com Beacon(HTTPS) windows success
----> 10.10.10.5 mail.whatta.com Beacon(SMB) windows success
-----> 192.168.57.18 dev.joshrocks.local SSH unix success
----> 10.10.10.3 joshdev.whatta.com Beacon(SMB) windows success
-----> 192.168.57.8 files.joshrocks.local RDP windows fail bad creds
```

### Parser regex (per line after header)
```
^(-+>) (\S+) (\S+) (\S+) (\S+) (\S+)\s*(.*)$
```

---

## Section 3: Log Body

**Indent level**: 0

### Header
```
Logs
```

The log body contains Host Header blocks, each containing Tool Header blocks, each containing command entries.

---

## Section 4: Host Header

**Indent level**: 0

### Format
```
====================================
IP:          <ip_address>
FQDN:        <fqdn>
NT Domain:   <netbios_domain>
DHCP Domain: <dhcp_domain_or_NA>
DHCP Ends:   <dhcp_expiry_or_NA>
MAC:         <mac_address>
====================================
```

### Fields
| Field | Format | Description |
|-------|--------|-------------|
| `IP` | IPv4 or IPv6 | Host IP address |
| `FQDN` | String | Full FQDN, not just hostname |
| `NT Domain` | String | NETBIOS domain name |
| `DHCP Domain` | String or `N/A` | DHCP-provided FQDN suffix |
| `DHCP Ends` | Date string or `N/A` | DHCP lease expiration |
| `MAC` | `XX:XX:XX:XX:XX:XX` | MAC address of primary NIC on target network |

### Delimiter
- Preceded and followed by a line of `=` characters
- The `=` line length should match the header content width

### Parser regex (key-value pairs inside `===` delimiters)
```
^={3,}$                          # delimiter line
^IP:\s+(.+)$
^FQDN:\s+(.+)$
^NT Domain:\s+(.+)$
^DHCP Domain:\s+(.+)$
^DHCP Ends:\s+(.+)$
^MAC:\s+(.+)$
^={3,}$                          # closing delimiter
```

---

## Section 5: Artifacts Header

**Indent level**: 0 (appears after the host header closing `===` line, followed by its own `===` line)

### Format
```
Artifacts
- Type: <File|Registry|Injection|Process|Other>
  Location: <file_path_or_location>
  AddlDetails: Description: <desc> | MD5: <hash> | Changes Made: <changes> | Original Setting: <setting> | Cleanup: <cleanup>
  CreationTime: <HHMM>Z
  CreationDate: <YYYY-MM-DD>
  Cleaned: <Y|N>
  RemovalTime: <HHMM>Z
  RemovalDate: <YYYY-MM-DD>
====================================
```

### Artifact Types
- `File`
- `Registry`
- `Injection`
- `Process`
- `Other`

### AddlDetails Sub-fields (pipe-delimited on single line)
| Sub-field | Description |
|-----------|-------------|
| `Description` | What the artifact is |
| `MD5` | Hash of the artifact file |
| `Changes Made` | What was changed on the system |
| `Original Setting` | What existed before (or `N/A`) |
| `Cleanup` | Cleanup action taken or planned |

---

## Section 6: Tool Header

**Indent level**: 1 (4 spaces)

### Format
```
    ***<ToolType> <T_ID> <pid> <processname> <user>
        <YYYY-MM-DD> <HH:MM> [*] ConfigID: <#>
```

### Fields
| Field | Description | Values |
|-------|-------------|--------|
| `ToolType` | Type of implant/tool | `Beacon`, `Shell`, `Runtime`, `Meterpreter`, `Tool` |
| `T_ID` | Document-unique tool instance ID | `T####` format (auto-generated) or beacon ID for Cobalt Strike |
| `pid` | Process ID | Integer |
| `processname` | Process name | e.g., `OPM_WAR_WRITER.exe` |
| `user` | User context | e.g., `target`, `SYSTEM`, `domain\username` |
| `Timestamp` | When the tool was established | `YYYY-MM-DD HH:MM` in ZULU |
| `[*]` | Literal marker | Always present |
| `ConfigID` | Links to Beacon Log CONFIG ID column | Integer |

### Parser regex
```
^ {4}\*\*\*(\S+) (\S+) (\d+) (\S+) (\S+)$
^ {8}(\d{4}-\d{2}-\d{2}) (\d{2}:\d{2}) \[\*\] ConfigID: (\d+)$
```

---

## Section 7: Command Input Line

**Indent level**: 2 (8 spaces)

### Format
```
        <YYYY-MM-DD> <HH:MM> <command_text>
```

### Fields
| Field | Format | Description |
|-------|--------|-------------|
| `Timestamp` | `YYYY-MM-DD HH:MM` | When the command was executed (ZULU) |
| `Command` | Free text | The actual command entered. **This is the field the script must parse to match T-Codes but must NOT include in output (per REQ-5).** |

### Parser regex
```
^ {8}(\d{4}-\d{2}-\d{2}) (\d{2}:\d{2}) (.+)$
```

---

## Section 8: Command Output

**Indent level**: 3 (12 spaces)

### Format
```
            [+] <output_text>     # Success
            [-] <output_text>     # Failure
            [!] <output_text>     # Warning
            [*] <output_text>     # Note/Info
```

### Output Symbols
| Symbol | Meaning |
|--------|---------|
| `[+]` | Success |
| `[-]` | Failure |
| `[!]` | Warning |
| `[*]` | Note/Info |

### Long output reference format
```
            [*] saved to /<YYYYMMDD>/shell/<hostname_IP>/<HHMM_toolname><_optionalinfo>.txt
```

### Parser regex
```
^ {12}\[([\+\-\!\*])\] (.+)$
```

---

## Section 9: Comments

**Indent level**: Same as the associated log item

### Format
```
        <YYYY-MM-DD> <HH:MM> [*] <comment_text>
```

- Placed on the line **above** the associated log item
- Begin with timestamp followed by `[*]`
- Lines starting with `#` are also comments (via Ctrl+/ shortcut)

---

## Section 10: Deviations

**Indent level**: Same as the associated input line

### Format
```
        [~] Approval: <TL|TC> <approver_last_name>
```

- Placed on the line **above** the associated command input line
- `[~]` is the deviation symbol

---

## Overall Document Structure (top to bottom)

```
MSN Name: ...
MSN Date: ...
Operator(s): ...

Scheme Of Maneuver
-> ...
--> ...

Logs
====================================
IP:          ...
FQDN:        ...
NT Domain:   ...
DHCP Domain: ...
DHCP Ends:   ...
MAC:         ...
====================================
Artifacts
- Type: ...
  ...
====================================
    ***Beacon T0001 5757 proc.exe user
        2025-06-10 20:46 [*] ConfigID: 1
        2025-06-10 20:47 whoami
            [+] DOMAIN\user
        2025-06-10 20:48 ipconfig
            [+] 10.10.10.5 ...
====================================
IP:          ...
...  (next host block)
```

---

## File Location in Mission Kit

```
MissionData/
├── logs/
│   └── <operation_identifier>/
│       └── Daily_Logs/
│           └── YYYYMMDD/
│               ├── Log/
│               │   ├── YYYYMMDD <Operator>.msn        # <-- THIS IS THE INPUT FILE
│               │   └── YYYYMMDD_TL_<Last Name>.csv
│               ├── Down/
│               │   └── <hostname_IP>/
│               ├── Shell/
│               │   └── <hostname_IP>/
│               │       └── <timestamp> <tool_name><optional>.file
│               ├── Up/
│               ├── Operator_Logs/
│               │   └── <symbolic links to daily logs>
│               └── TechLead/
│                   └── <symbolic links to TL daily logs>
├── Artifacts.csv                    # Master artifact log
└── Beacons.csv                      # Master beacon log
```
