# Output Spreadsheet Schema (CONFIRMED from Scorebook Prototype)

Source: `Project 1 - ScorebookPrototype by Misfire.xlsx` — visually confirmed via screenshots of the live workbook.

---

## Workbook Tab Structure

The Scorebook is a multi-tab Excel workbook. The tabs are:

| Tab Name | Purpose | Script Responsibility |
|----------|---------|----------------------|
| **Cover Sheet & Metadata** | Mission overview: team ID, defended networks, red/blue objectives, pass/fail, mission kill time, first detection | **Script populates partially** — see details below |
| **Master Set & Scoring** | **PRIMARY OUTPUT TAB** — one row per Red action with T-Code, tactic, critical path flag, endpoints, and timestamp | **Script populates columns A–F** |
| **Enterprise ATT&CK (v17)** | Reference lookup of all MITRE ATT&CK v17 technique names organized by tactic column. Red-highlighted cells = techniques observed during the mission | **Script may highlight used techniques** (or this is done manually) |
| **Example Set** | Scoring summary — counts and percentages of detected vs. executed techniques per ATT&CK tactic, plus a bar chart | **Derived from per-tactic tabs** — likely formula-driven |
| **Vul1** (and Vul2, Vul3...) | Per-vulnerability scoring sheet — one tab per vulnerability window in the exercise | **Populated by White Cell / assessors**, not the script |
| **Initial Access** | Per-tactic tab for Initial Access techniques | **Populated by White Cell** using Master Set data |
| **Execution** | Per-tactic tab | **Populated by White Cell** |
| **Persistence** | Per-tactic tab | **Populated by White Cell** |
| **Privilege Escalation** | Per-tactic tab | **Populated by White Cell** |
| **Defense Evasion** | Per-tactic tab | **Populated by White Cell** |
| **Credential Access** | Per-tactic tab | **Populated by White Cell** |
| **Discovery** | Per-tactic tab | **Populated by White Cell** |
| **Lateral Movement** | Per-tactic tab | **Populated by White Cell** |
| **Collection** | Per-tactic tab | **Populated by White Cell** |
| **Command and Control** | Per-tactic tab | **Populated by White Cell** |
| **Exfiltration** | Per-tactic tab | **Populated by White Cell** |
| **Impact** | Per-tactic tab | **Populated by White Cell** |

---

## Tab 1: Cover Sheet & Metadata

### Layout (confirmed)

| Row | Column A | Column B | Column C |
|-----|----------|----------|----------|
| 1 | `Team: <unit_id>` (e.g., "Team: 854 CPT") | | |
| 2 | `STATUS:` | `PASS/FAIL` | |
| 3 | *(blank)* | | |
| 4 | `Defended Network` | | |
| 5 | `<subnet>` (e.g., 192.168.10.0/24) | `<network_name>` (e.g., "Shared Workstations") | |
| 6 | `<subnet>` | `<network_name>` (e.g., "Engineering") | |
| 7 | `<subnet>` | `<network_name>` (e.g., "AOC Operational Network") | |
| 8 | *(blank)* | | |
| 9 | `Red Objectives` | | `Approx. Time Completed` |
| 10+ | `<objective_description>` | `[x]` or `[ ]` | `INCOMPLETE` or `[END VUL]` or time |
| ... | *(blank row separator)* | | |
| N | `Blue Objectives` | | |
| N+1 | `<objective_description>` | `[x]` or `[ ]` | |
| ... | *(blank row separator)* | | |
| M | `Red Mission Kill?` | `<HH:MM:SSZ>` or empty | |
| M+1 | `Red access denied?` | `Yes` or `No` | |
| M+2 | `Earliest Detection Time/First Blood` | `Vul <#>@<HH:MM:SSZ>` | |
| M+3 | `First tactic detected` | `<T-Code>` (e.g., "T10XX") | |

### Script responsibility
- The script itself likely does **not** populate this tab — it's filled by the TL/TC based on mission context.
- However, the script could auto-populate: `First tactic detected` (earliest T-Code by timestamp) and `Earliest Detection Time` if detection data is available.

---

## Tab 2: Master Set & Scoring — CONFIRMED COLUMNS

This is the **primary tab the script must populate**.

### Column Definitions (A through F confirmed)

| Column | Header Name (exact) | Data Type | Populated By | Description |
|--------|---------------------|-----------|-------------|-------------|
| **A** | `ID (specify T Code unless Flagged in Red)` | String | **Script** | MITRE ATT&CK technique ID (e.g., `T1566`, `T1547.001`, `T1204`). If the command cannot be auto-mapped, the cell text is `TXXXX.XX` and the **row is highlighted in red** for manual review. |
| **B** | `Technique` | String | **Script** | The ATT&CK technique name / tactic label (e.g., "Phishing", "User Execution", "Registry Run Keys/Startup Folder", "Boot or Logon Autostart Execution", "Local Discovery", "Network Discovery", "Domain Discovery", "SMB Lateral Movement", "Toolset Transposition", "Callback", "Credential dumping", "File access", "Data Exfil"). For flagged rows, the format is: `**FLAG: "<actual_command_text>" **FLAG` |
| **C** | `Critical Path? (Lateral Movement, Persistence)` | String | **Script** | `Y` if the technique is Lateral Movement or Persistence; `N` otherwise. For flagged rows: `?` |
| **D** | `Endpoint Executed On` | String | **Script** | IPv4/IPv6 address or hostname of the target machine. Must be syntactically valid. |
| **E** | `Endpoint Executed From` | String | **Script** | IPv4/IPv6 address or hostname of the machine the command was executed from. For lateral movement rows, may show a transition like `192.168.10.51 (WINUSR1) to 192.168.100.10 (WIN2016_DC)` — though that format appeared on the Vul1 tab, not Master Set. |
| **F** | `Observable on-net starting: (Should be Operator timestamp)` | String | **Script** | Timestamp in format `VulX@HH:MM:SSZ` where `X` is the vulnerability window number (e.g., `Vul1@15:32:00Z`, `VulX@12:34:56Z`). For initial access / TA-assisted entries: `N/A; TA assist initial access. (manually added by Tech Lead)` |

### Key Observations from Sample Data

1. **Flagged/unmatched rows**: When a command can't be auto-mapped to a T-Code:
   - Column A = `TXXXX.XX`
   - Column B = `**FLAG: "<full command text>" **FLAG`
   - Column C = `?`
   - The entire row gets a **red/pink background** highlight
   - This is the REQ-3 "manual adjustment" case

2. **T-Code granularity**: The ID column uses full sub-technique IDs when known (e.g., `T1547.001`) and placeholder `TXXXX.XX` when unknown. Some entries use just the tactic-level number (e.g., `1087` — probably shorthand for `T1087`).

3. **Technique names**: Column B uses human-readable names that are more descriptive than strict MITRE names. Examples include "Local Discovery", "Network Discovery", "SMB Lateral Movement", "Toolset Transposition", "Callback", "Files encrypted for impact" — some are custom 57 IAS labels, not canonical MITRE names.

4. **Timestamp format**: The `VulX@HH:MM:SSZ` format embeds which vulnerability window the action occurred in. This means the script needs to know which vulnerability window is active at a given ZULU time, or the operator/TL assigns it.

5. **First row special case**: Row 2 in the sample shows `T1566 / Phishing / N` with `N/A` for observable time — this was a TA-assisted initial access manually added by the TL, not parsed from an operator log.

---

## Per-Tactic Tabs — CONFIRMED COLUMNS

Each per-tactic tab (Initial Access, Execution, Persistence, etc.) and each Vul tab share the same column structure:

| Column | Header Name (exact) | Populated By |
|--------|---------------------|-------------|
| **A** | `ID` | White Cell (copies from Master Set column A) |
| **B** | `Tactic` | White Cell (copies from Master Set column B) |
| **C** | `Critical?` | White Cell (copies from Master Set column C) |
| **D** | `Score` | **White Cell / Assessor** — numeric score or `X` |
| **E** | `Endpoint` | White Cell (single endpoint, from Master Set D or E) |
| **F** | `Approx Observable Time` | White Cell (from Master Set column F) |
| **G** | `Detection Time` | **White Cell / Assessor** — when Blue detected it. Format: `VulX@HH:MM:SSZ` or `N/A` |
| **H** | `Clear/Remediation Time` | **White Cell / Assessor** — when Blue remediated. Same format |
| **I** | `Hardening Action` | **White Cell / Assessor** — `Done`, `Cannot Be hardened`, `N/A`, or blank |
| **J** | `Evaluator Comments` | **White Cell / Assessor** — free text (e.g., "Skill Issue", "Detected via EndGame Alert report") |

### Script responsibility for per-tactic tabs
The script does **not** directly populate these tabs. The White Cell / assessors distribute Master Set rows into the appropriate per-tactic tab and add scoring columns (D, G, H, I, J). However, a future enhancement could auto-distribute rows by T-Code family.

---

## Example Set Tab

### Structure (confirmed)
- **Row 3**: ATT&CK tactic category headers across columns (Execution, Persistence, Privilege Escalation, Defense Evasion, Credential Access, Discovery, Lateral Movement, Collection, Command and Control, Exfiltration, Impact)
- **Rows 4-7**: Specific technique names under each tactic, with red-highlighted cells for techniques that were used but not detected
- **Row 12**: Same tactic headers (with checkboxes)
- **Row 13**: Count of techniques executed per tactic
- **Row 14**: Count of techniques detected per tactic
- **Row 15**: Detection percentage per tactic (e.g., 100%, 67%, 50%)
- **Row 16**: Zeros row (possibly undetected count)
- **Below**: Bar chart titled "Example of Full" — dual-axis chart showing TTP count (green/red bars) and detection percentage (line) per tactic

### Script responsibility
This tab is formula/chart-driven from the per-tactic tabs. The script does not directly populate it, but its Master Set output feeds the chain.

---

## Enterprise ATT&CK (v17) Tab

### Structure (confirmed)
- Column headers are ATT&CK tactic names (Lateral Movement, Collection, Command and Control, Exfiltration, etc.)
- Each column lists the sub-techniques for that tactic
- Cells highlighted in **red** = techniques that were observed/used during the mission
- This serves as a visual reference and may use conditional formatting linked to the Master Set

---

## Output Rules (Updated)

1. **One row per parsed action** in the Master Set & Scoring tab.
2. **Columns A–F** are the script's responsibility. Everything beyond column F is White Cell territory.
3. **Sort by timestamp** — the `VulX@HH:MM:SSZ` format in column F.
4. **Unmatched commands**: Column A = `TXXXX.XX`, Column B = `**FLAG: "<cmd>" **FLAG`, Column C = `?`, row highlighted red.
5. **No command text** for matched rows — Column B shows the technique name only (REQ-5).
6. **Critical Path**: Column C = `Y` for Lateral Movement or Persistence; `N` otherwise.
7. **Vulnerability window**: The script must either determine which Vul window a timestamp falls in, or accept it as input. The format `VulX@HH:MM:SSZ` requires knowing the Vul number.

---

## Open Question: Vulnerability Window Mapping

The timestamp format `VulX@HH:MM:SSZ` requires knowing which vulnerability window (Vul1, Vul2, etc.) each action falls into. This mapping is likely defined in the mission plan or Cover Sheet (which lists Vul windows with start/end times). The script may need:
- A config input specifying Vul window time ranges, OR
- The operator to annotate which Vul window each log segment belongs to, OR
- A simple rule like "all actions on date X = Vul1"
