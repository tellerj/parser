# vscode-msnlog Extension Specification (v2.0.0)

Source: `vscode-msnlog-2.0.0.vsix` — extracted and analyzed.

This document describes the 57 IAS "Mission Logs" VS Code extension, which defines the `.msn` file format, provides syntax highlighting, linting, snippets, and two built-in data extraction commands. **The extension contains a complete Lark grammar and Python parser that can be reused directly by the metadata script.**

---

## Overview

- **Extension ID**: `57ias.vscode-msnlog`
- **Version**: 2.0.0
- **Language ID**: `msnlog`
- **File extension**: `.msn`
- **Repository**: `https://gitlab.cave.lan/mission_support/vscode-msnlog` (internal)
- **Architecture**: TypeScript client + Python LSP server (using `pygls` and `lark` parser)

---

## Key Discovery: Reusable Parser

The extension bundles a **Lark LALR parser** (`msnlog.lark`) and Python visitor classes (`lexer_parser.py`) that already parse `.msn` files into structured data. The metadata script can **directly reuse** these components rather than building a parser from scratch.

### Files to reuse
```
extension/bundled/tool/msnloglib/msnlog.lark      # Lark grammar (formal .msn format spec)
extension/bundled/tool/msnloglib/lexer_parser.py   # Parser + visitor classes
extension/bundled/libs/lark/                       # Lark library (bundled)
```

### Built-in extraction commands

The extension already implements two commands that extract structured data from parsed `.msn` files:

1. **`vscode-msnlog.genArtifacts`** — extracts all artifacts across all hosts into CSV format
2. **`vscode-msnlog.genChronoLogs`** — extracts all command entries in chronological order as a list of dicts

The `genChronoLogs` output structure is **almost exactly** what the metadata script needs:

```python
{
    'datetime': '2025-06-10 20:57',       # ZULU timestamp
    'command': 'env',                      # Command name (first token)
    'args': '',                            # Command arguments (rest of line)
    'result': 'OUTPUTSUCCESS',             # One of: OUTPUTSUCCESS, OUTPUTFAIL, OUTPUTWARNING, OUTPUTNOTE
    'output': ['Results saved to ...'],    # List of output lines
    'mission': {
        'name': 'Example Mission',
        'operators': ['Snuffy']
    },
    'host': {
        'fqdn': 'target1.test.mil',
        'ipv4': '192.168.76.11',
        'mac': 'AB:CD:EF:AB:CD:EF'
    },
    'tool': {
        'type': 'CobaltStrikeBeacon',      # or NighthawkBeacon, Shell, Meterpreter, Tool
        'id': 'T704143',                   # Tool instance ID
        'proc_id': '5757',                 # PID
        'proc_name': 'OPM_WAR_WRITER.exe', # Process name
        'proc_user': 'target'              # User context
    }
}
```

**To build the metadata script**: Parse the `.msn` file with the Lark grammar, run `get_chrono_logs()`, then map each entry's `command` field against `T_CODE_LOOKUP.json`, and output to Excel.

---

## Lark Grammar Summary

The grammar file `msnlog.lark` formally defines the `.msn` format. Key rules:

### Document Structure
```
start → comments* msnlogheader msnlogschemeofmaneuver logs
```

### Mission Header
```
msnlogheader → "MSN Name:" MSNNAME NEWLINE
               "MSN Date:" LOGDATE NEWLINE
               "Operator(s):" OPERATOR ("," OPERATOR)* NEWLINE
```

### Scheme of Maneuver
```
msnlogschemeofmaneuver → "Scheme Of Maneuver" NEWLINE maneuver+
maneuver → SCHEMEOFMANEUVERLEVEL IPV4 FQDN CONNECTTYPE OS CONNECTRESULT NEWLINE
```
- `SCHEMEOFMANEUVERLEVEL` = regex `/-+>(?=\s)/` (matches `->`, `-->`, `--->`, etc.)

### Logs / Host Sections
```
logs → "Logs" NEWLINE host+
host → BORDER NEWLINE
       "IP:" IPV4 NEWLINE
       "FQDN:" FQDN NEWLINE
       "NT Domain:" NTDOMAIN NEWLINE
       "DHCP Domain:" DHCPDOMAIN NEWLINE
       "DHCP Ends:" DHCPEND NEWLINE
       "MAC:" MAC NEWLINE
       BORDER NEWLINE
       "Artifacts" NEWLINE
       artifact*
       BORDER NEWLINE
       INDENT hostlogs DEDENT
```

### Artifacts
```
artifact → "- " "Type:" ARTIFACTTYPE NEWLINE
           INDENT
             "Location:" DATA NEWLINE
             "AddlDetails:" DATA NEWLINE
             "CreationTime:" ARTIFACTTIME NEWLINE   # Format: HHMMz (e.g., 2043Z)
             "CreationDate:" LOGDATE NEWLINE
             "Cleaned:" ("Y"|"N") NEWLINE
             "RemovalTime:" (ARTIFACTTIME | "XX") NEWLINE
             "RemovalDate:" (LOGDATE | "XX") NEWLINE
           DEDENT
```
- `ARTIFACTTYPE` = regex `/(?:File|Registry|Injection|Process|Other)/i`
- `ARTIFACTTIME` = regex `/(?:[01][0-9]|2[0-3])[0-5][0-9]Z/` (e.g., `2043Z`)

### Tool Logs
```
hostlogs → (COMMENT | toollog)+
toollog → "***" TOOLNAME TOOLIDENTIFIER PROCESSID PROCESSNAME USERNAME NEWLINE
          INDENT (toolio | toolcont | deviation | narrative | COMMENT)+ DEDENT
```
- `TOOLNAME` = regex `/(CobaltStrikeBeacon|NighthawkBeacon|Shell|Meterpreter|Tool)\b/`
- `TOOLIDENTIFIER` = regex `/T\d{4,}/` (e.g., T704143 — note: 4+ digits, not exactly 4)

### Command I/O
```
toolio → LOGDATETIME COMMAND [COMMANDARGS] NEWLINE INDENT tool_output DEDENT
tool_output → outputstatus [OUTPUTLINE] NEWLINE ...
```
- `LOGDATETIME` = regex `/\d{4}-\d{1,2}-\d{1,2} \d{1,2}:\d{1,2}\b/`
- `COMMAND` = single word (no spaces)
- `COMMANDARGS` = rest of line after command (optional)
- Output status: `[+]` success, `[-]` fail, `[!]` warning, `[*]` note

### Narratives (operator notes without commands)
```
narrative → LOGDATETIME "[*]" NARRATIVENOTE NEWLINE
```
These are timestamped notes (not commands). The parser separates them from `toolio` entries.

### Deviations
```
deviation → "[~]" DEVIATIONNOTE NEWLINE
```

### Tool Continuation References
```
toolcont → LOGDATETIME "[CONT@T######]" NEWLINE
```
Format: `[CONT@T<digits>]` — references another tool's log when switching context.

---

## Snippet Templates (exact output format)

These define the exact text the extension inserts when operators use keyboard shortcuts:

### Mission Header (Ctrl+Alt+M)
```
MSN Name: <MissionFileName>
MSN Date: YYYY-MM-DD
Operator(s): <Operator1>,<Operator2>

Scheme of Maneuver
-> X.X.X.X  FQDN.NAME ACCESS_METHOD OS success
--> X.X.X.X  FQDN.NAME ACCESS_METHOD OS success
```

### Host Header (Ctrl+Alt+H)
```
==================================
IP:          X.X.X.X
FQDN:        FQDN.NAME
NT Domain:   NT.DOMAIN
DHCP Domain: DHCP.DOMAIN
DHCP Ends:   Month X,20XX X:XX:XX XX
MAC:         XX:XX:XX:XX:XX:XX
==================================
Artifacts

==================================

    <cursor>
```
Note: The Host Header snippet includes an empty Artifacts section with borders. Tool headers go after the closing `===` line.

### Beacon/Tool Header (Ctrl+Alt+B)
```
***<ToolType> T<RANDOM> <pid> <processname> <user>
    YYYY-MM-DD HH:MM [*] Config ID: <configID>
    <cursor>
```
- `ToolType` choices: `CobaltStrikeBeacon`, `NighthawkBeacon`, `Shell`, `Meterpreter`, `Tool`
- Note: snippet says `Config ID` (with space), example log shows `ConfigID` (no space). The grammar accepts both since it just captures as DATA after `[*]`.
- `T<RANDOM>` generates a random numeric ID (6 digits from VSCode's `${RANDOM}`)

### Artifact (Ctrl+Alt+A)
```
- Type: <File|Registry|Injection|Process|Other>
  Location: <Path/file name, registry path/key/value/data, process name/PID>
  AddlDetails: <MD5 hash, original config setting, mission share path to original file, etc>
  CreationTime: HHMMZ
  CreationDate: YYYY-MM-DD
  Cleaned: <N|Y>
  RemovalTime: XX
  RemovalDate: XX
```

### Output Symbols
```
[+]    # Ctrl+Alt+=   (Success)
[-]    # Ctrl+Alt+-   (Fail)
[!]    # Ctrl+Alt+1   (Warning)
[*]    # Ctrl+Alt+8   (Note)
[~]    # Ctrl+Alt+D   (Deviation) → "[~] Approval: "
```

### Timestamp (Ctrl+Alt+T)
```
YYYY-MM-DD HH:MM <cursor>
```

---

## Indentation Rules

The extension uses a `TreeIndenter` with `tab_len = 2` for the Lark parser's indentation tracking. However, per the SOP, actual indentation in the file is 4 spaces per level. The `tab_len = 2` controls the parser's internal indent detection sensitivity, not the visual spacing.

The `language-configuration.json` defines:
- **Comment character**: `#`
- **Folding markers**: Lines starting with `={3,}` (host header borders)
- **Auto-indent**: After command input lines (lines matching `^\s+(\d{4}-\d{1,2}-\d{1,2} \d{1,2}:\d{1,2})`)

---

## Parser Error Recovery

The linter uses Lark's `on_error` recovery mechanism. When a parsing error occurs:
1. It captures the error as an LSP diagnostic (shown as red squiggly in VS Code)
2. It feeds a dummy token to continue parsing
3. It reports up to `maxNumberOfProblems` errors (default: 20)

This means operators see real-time validation errors in their logs. The metadata script should similarly validate logs before processing.

---

## Important Format Details Confirmed by Grammar

1. **TOOLIDENTIFIER is `T` followed by 4+ digits** — not exactly 4 as the SOP suggests. The example shows `T704143` (6 digits). The regex is `/T\d{4,}/`.

2. **Tool types include `CobaltStrikeBeacon` and `NighthawkBeacon`** — the SOP only mentions `Beacon` generically, but the grammar is specific. `NighthawkBeacon` is a second C2 framework.

3. **COMMAND is a single word** (no spaces). Everything after it on the same line is `COMMANDARGS`. This means T-Code matching should use only the first token.

4. **Narrative entries** (`LOGDATETIME [*] text`) are distinct from command I/O. They are operator notes and should generally be **excluded** from the metadata output (they're not "actions" that map to T-Codes).

5. **Tool continuation** (`[CONT@T######]`) is a cross-reference mechanism. When an operator switches between tools, they can reference another tool's context.

6. **Artifact time format** is `HHMMZ` (no colon, with Z suffix) — different from command timestamps which are `HH:MM`.

7. **The parser expects a `#` comment header** at the top of the file (distribution statement), followed by mission metadata. This is optional but standard.

---

## Implementation Recommendation

Rather than building a new parser, the metadata script should:

1. **Import the Lark grammar and parser directly** from the VSIX bundle
2. Call `parse_log(doc_text, max_problems)` to get the parse tree
3. Call `get_chrono_logs(tree)` to get chronologically sorted command entries
4. Map each entry's `command` field against `T_CODE_LOOKUP.json`
5. Format the output into the Master Set & Scoring Excel schema

The Lark grammar + Python visitors are production-tested (used daily by 57 IAS operators) and handle edge cases the metadata script would otherwise need to discover through trial and error.
