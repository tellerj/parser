# Missing Resources and Open Questions

This file documents gaps, unknowns, and resources that a future agent will need to resolve before or during implementation.

---

## RESOLVED Items

### ~~1. Scorebook Prototype (Password-Protected)~~ — RESOLVED
- **File**: `Project 1 - ScorebookPrototype by Misfire.xlsx`
- **Status**: ~~Encrypted~~ → **Visually confirmed** via browser-based Excel screenshots. All tabs and column structures documented in `OUTPUT_SCHEMA.md`.
- **Remaining gap**: The file still can't be opened programmatically (CDFV2 encrypted). An unprotected copy would be useful if the script needs to use it as a template (copying formatting, formulas, chart structure). For now, the schema is fully documented from screenshots.

### ~~2. Sample Operator Log (.msn file)~~ — RESOLVED
- **Status**: ~~Not provided~~ → **Found inside the vscode-msnlog VSIX extension** as `exampleMsnLog.msn`. Copied to `agent-ready/EXAMPLE_OPERATOR_LOG.msn`.
- **Remaining gap**: This is a synthetic example, not a real mission log. Real-world logs may have additional edge cases. Ideally still obtain 2-3 sanitized real logs from different operators on the same mission to test merge/sort (REQ-4).

### ~~4. vscode-msnlog Extension Source or Documentation~~ — RESOLVED
- **File**: `vscode-msnlog-2.0.0.vsix`
- **Status**: ~~Not provided~~ → **Fully extracted and analyzed**. Contains a complete Lark LALR grammar (`msnlog.lark`), Python parser with visitor classes, snippet templates, and syntax highlighting rules. All documented in `VSIX_EXTENSION_SPEC.md`.
- **Key finding**: The extension already has a `ChronoLogger` visitor that extracts exactly the data structure the metadata script needs. The script can **reuse the Lark grammar and parser directly** rather than building one from scratch.

---

## Still Missing Resources

### 3. 57 IAS Logo Image
- **Status**: Not provided.
- **Impact**: LOW (extra credit only). Required for REQ-EC-2 (logo in spreadsheet header).
- **Action needed**: Obtain a `.png` or `.jpg` of the 57 IAS unit patch/logo.

### 5. Vulnerability Window Time Ranges — LOW / Design Decision
- **Status**: Not explicitly provided in the prototype, but the Cover Sheet & Metadata tab is the natural home for this data. The prototype is an early draft; the Vul-to-time mapping was likely just not yet added.
- **Impact**: **LOW** — this is a minor design decision, not a blocker. The script simply needs a lookup from Vul number to start/end ZULU times so it can convert raw timestamps (e.g., `2025-06-10 15:32`) into the Scorebook format (`Vul1@15:32:00Z`).
- **Recommended approach**: Read Vul window definitions from the Cover Sheet & Metadata tab (or a dedicated config input). Expected format:
  ```
  Vul 1 = 2025-06-10 12:00:00Z – 2025-06-10 16:00:00Z
  Vul 2 = 2025-06-11 12:00:00Z – 2025-06-11 16:00:00Z
  ```
- **Edge case**: If a timestamp falls outside all defined Vul windows, flag it for manual review or use the nearest Vul window.

### 6. Technique Name Mapping
- **Status**: Partially available. The T-Code Lookup Table provides command-to-T-Code-family mappings, but the Scorebook uses descriptive technique names in column B (e.g., "Registry Run Keys/Startup Folder", "Boot or Logon Autostart Execution", "SMB Lateral Movement") that are more specific than the family names in the lookup table.
- **Impact**: MEDIUM. The script needs a mapping from T-Code IDs to human-readable technique names for column B.
- **Action needed**: Use the MITRE ATT&CK framework data (freely available as STIX/JSON from MITRE's GitHub) to map T-Code IDs to canonical technique names. Some 57 IAS names are custom (e.g., "Toolset Transposition", "Callback") and may need a supplemental mapping.

---

## Ambiguities in Requirements

### 7. "Endpoint Executed From" vs "Endpoint Executed On"
- **Question**: How should the script determine which endpoint a command was "executed from" vs "on"?
- **Evidence from Scorebook**: In the Master Set sample data, both columns D and E often show the **same IP** (e.g., both = `192.168.10.51`). For lateral movement entries, the Vul1 tab shows the transition format `192.168.10.51 (WINUSR1) to 192.168.100.10 (WIN2016_DC)` in the Endpoint column.
- **Likely answer**: For most commands, "Executed On" = the Host Header IP (target), and "Executed From" = the same IP (commands run locally on the compromised host). For lateral movement commands, "Executed From" = current host and "Executed On" = the remote target. For initial access, both may be the first foothold IP.
- **Note**: Some entries show hostnames like `floppydoodle.bats.mil` instead of IPs, confirming REQ-6 allows hostnames.

### 8. User-Defined T-Code Commands
- **Question**: 20 of the 144 commands are marked "User-Defined" with T-Code family that varies by context (e.g., `shell`, `run`, `powershell`, `inject`). How should the script handle these?
- **Evidence from Scorebook**: Flagged rows use `TXXXX.XX` in column A, `**FLAG: "<cmd>" **FLAG` in column B, and `?` in column C — with a red row highlight. This is exactly the unmatched/manual-review behavior.
- **Recommendation**: Flag all User-Defined commands using the same `**FLAG` format. This aligns with REQ-3 and the Scorebook's visual pattern.

### 9. Multiple T-Codes per Command
- **Question**: Some commands could map to multiple T-Codes (e.g., `mimikatz` could be Credential Access or Privilege Escalation).
- **Current handling**: The lookup table assigns one primary family. The `notes` field provides context.
- **Recommendation**: Use the primary mapping from the lookup table. If the command is User-Defined, flag for manual review.

### 10. Script Execution Timing
- **Question**: Should the script run before or after log sanitization?
- **Analysis**: Sanitization replaces passwords/hashes with `XXXXXXXXXX`. Since the script should not output command text anyway (REQ-5), running after sanitization is safer. However, if the script needs to parse credential-related commands for T-Code matching, it might need the original text.
- **Recommendation**: Run before sanitization, since the script redacts command text in its own output and needs the original command names for T-Code matching.

### 11. Beacon Log Integration
- **Question**: Does the script need to cross-reference the Beacon Log (`Beacons.csv`)?
- **Analysis**: The Tool Header contains a `ConfigID` that maps to the Beacon Log. The Scorebook's Master Set does not appear to have a ConfigID column (columns A-F confirmed), so this may not be needed in the direct output.
- **Recommendation**: ConfigID is not in the Master Set output. However, it may be useful for internal traceability during parsing.

### 12. Cover Sheet Population
- **Question**: Should the script populate the Cover Sheet & Metadata tab?
- **Evidence from Scorebook**: The Cover Sheet contains mission-level data (team ID, defended networks, objectives, mission kill time, first detection time, first tactic detected). Most of this is mission-planning data the script wouldn't have.
- **However**: The script *could* derive: `First tactic detected` (earliest T-Code by timestamp) and `Earliest Detection Time/First Blood` (earliest timestamp in the Master Set). `Red Mission Kill?` time is a subjective call.
- **Recommendation**: Populate `First tactic detected` automatically. Leave other Cover Sheet fields for TL/TC manual entry.

---

## Technical Considerations for Implementation

### Parsing Strategy
- The log format is structured but not strictly machine-formatted — operators type in real time with possible typos or formatting inconsistencies.
- The vscode-msnlog extension enforces some structure, but fallback text editors are allowed by the SOP.
- A robust parser should handle: missing fields, extra whitespace, slightly malformed headers, and edge cases.

### T-Code Matching Strategy
- First pass: exact match of command name against `T_CODE_LOOKUP.json` `command` field (strip arguments first — match only the first token of the command input line after the timestamp)
- Second pass: prefix/substring matching (e.g., `execute-assembly /path/to/tool.exe` should match `execute-assembly`)
- Third pass (extra credit): fuzzy matching or keyword-based suggestion (REQ-EC-1)
- For User-Defined commands: flag with `**FLAG` format

### Flagged Row Format (confirmed from Scorebook)
```
Column A: TXXXX.XX
Column B: **FLAG: "<full_command_text>" **FLAG
Column C: ?
Row formatting: Red/pink background highlight
```

### Timestamp Format Conversion
The operator log uses `YYYY-MM-DD HH:MM` (ZULU). The Scorebook output uses `VulX@HH:MM:SSZ`. The script must:
1. Parse the ZULU timestamp from the operator log
2. Determine which Vul window it falls into (requires Vul window config — see Missing Resource #5)
3. Output in `VulX@HH:MM:SSZ` format (adding `:00` seconds if the log only has HH:MM)

### Testing Strategy
- Unit tests needed for each log section parser
- Integration test: full `.msn` file parse to spreadsheet output
- Merge test: multiple operator files combined and time-sorted
- Edge cases: empty logs, logs with only comments, logs with no matched commands
- Validation: compare script output against the Scorebook Prototype's sample data rows
