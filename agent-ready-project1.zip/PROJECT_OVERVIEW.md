# Project 1: Mission Log Metadata Script Analyzer

## Organization

57th Information Aggressor Squadron (57 IAS), Nellis AFB, NV — a USAF Cyber Red Team unit.

## Project Summary

Build a script (the "Mission Log Metadata Script Analyzer") that ingests operator mission logs written during Red Team cyber operations and outputs a structured Excel spreadsheet of metadata. The spreadsheet is delivered to Blue Team / White Cell assessors so they can evaluate defensive detection gaps **without exposing Red Team TTPs**.

## Mission Context

- **Supported exercises**: Red Flag 26-3, and any future Red Flag / Black Eagle or Red-vs-Blue engagement with the 67th Cyberspace Wing (67 CW).
- **Capability type**: Custom / In-House tool.
- **Why it exists**: Blue forces need metadata about Red activity (timing, targets, MITRE ATT&CK T-Codes, lateral movement paths) to assess their own detection performance. Previously this was done by manual "hand-jamming," which is too labor-intensive for complex exercises.
- **Who consumes the output**: White Cell TAC Mentors / Assessors from the Blue unit. Red operators do **not** use the output directly.
- **Dashboard context**: The metadata feeds the top-left quadrant of a one-slider dashboard. The remaining quadrants reference draft ATRG for cyber operations, MITRE Threat Rating, and Environment Complexity level. "Mission Kill" is a subjective decision based on scenario.

## Classification

All materials provided are **UNCLASSIFIED**. The SOP itself is marked UNCLASSIFIED and signed by the Director of Operations.

## Source Documents

| File | Description |
|------|-------------|
| `Project 1 - Capability Request.docx` | Defines what the script must do, its requirements, justification, and intended use |
| `Project 1 - Mission Logging SOP (CAO 20250611) --signed.pdf` | 27-page SOP defining the exact format of operator logs, artifact logs, beacon logs, TL daily logs, and master station logs |
| `Project 1 - ScorebookPrototype by Misfire.xlsx` | Password-protected Excel file showing the visual template for the output spreadsheet. Only the non-hidden columns in the "Master Set & Scoring" tab are relevant. **Currently inaccessible — password required.** |
| `Project 1 - T-Code Lookup Tables.xlsx` | Mapping of 57 IAS tool/command names to MITRE ATT&CK T-Codes (144 entries + 16-row lookup table of T-Code families) |

## Key Terminology

- **Operator**: The person executing commands on target systems during a Red Team mission.
- **Technical Lead (TL)**: Manages the mission kit file structure, artifact logs, beacon logs, and TL daily logs.
- **Team Chief (TC)**: Maintains the Master Station Log (MSL) on NIPR.
- **Mission Kit**: The portable file system carried to the operation site containing all tools, logs, and templates.
- **Battlestation**: The operator workstation.
- **T-Code**: MITRE ATT&CK tactic/technique identifier (e.g., TA0005 = Defense Evasion, T1082 = System Information Discovery).
- **BOF**: Beacon Object File — a small compiled program executed within a Cobalt Strike beacon.
- **Cobalt Strike**: The primary command-and-control framework used by 57 IAS.
- **vscode-msnlog**: A custom VS Code extension used for structured mission logging.
- **Scheme of Maneuver**: A section at the top of each operator log describing the network path (pivot chain) the operator used.
- **ZULU time**: UTC. All mission logs use ZULU timestamps.
