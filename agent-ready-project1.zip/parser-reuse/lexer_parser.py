from datetime import datetime
from pathlib import Path

from lark import Lark, indenter, UnexpectedInput, UnexpectedToken, Token, ParseTree
from lark.visitors import Visitor_Recursive
import lsprotocol.types as lsp

class TreeIndenter(indenter.Indenter):
    NL_type = '_NEWLINE'
    OPEN_PAREN_types = []
    CLOSE_PAREN_types = []
    INDENT_type = '_INDENT'
    DEDENT_type = '_DEDENT'
    tab_len = 2

    def handle_NL(self, token):
        try:
            yield from super().handle_NL(token)            
        except indenter.DedentError:
            raise UnexpectedToken(token=token,expected=Token('_DEDENT', ''))

class ArtifactGetter(Visitor_Recursive):
    """Visitor for extracting artifacts from all hosts in a mission log
    """
    def __init__(self):
        self.curr_host = None
        self.artifacts = []
        super().__init__()
    

    def host(self, tree):
        hostinfo = tree.children
        self.curr_host = {
            'fqdn': hostinfo[1].value,
            'ipv4': hostinfo[0].value
            }
        
    def artifact(self, tree):
        members = tree.children
        self.artifacts.append({
            **self.curr_host,
            'type': members[0],
            'location': members[1],
            'details': members[2],
            'create_time': members[3],
            'create_date': members[4],
            'cleaned': members[5],
            'removal_time': members[6],
            'removal_date': members[7],
        })

    def reset(self):
        self.curr_host = None
        self.artifacts = []

class ChronoLogger(Visitor_Recursive):
    """Visitor for extracting logs in chronological order
    """
    def __init__(self):
        # [!] WARNING: make sure none of these names overlap with rule names in the tree
        self.curr_host = None
        self.mission = None
        self.tool = None
        self.chrono_logs = []
        super().__init__()    

    def msnlogheader(self, tree):
        msn = tree.children
        self.mission = {
            'name': msn[0],
            'operators': msn[2:]
        }

    def host(self, tree):
        hostinfo = tree.children
        self.curr_host = {
            'fqdn': hostinfo[1].value,
            'ipv4': hostinfo[0].value,
            'mac': hostinfo[5].value,
            }
    
    def toollog(self, tree):
        tool = tree.children
        self.tool = {
            'type': tool[0],
            'id': tool[1],
            'proc_id': tool[2],
            'proc_name': tool[3],
            'proc_user': tool[4]
        }

    def toolio(self, tree):
        toolio = tree.children
        self.chrono_logs.append({
            'datetime': datetime.strptime(toolio[0],'%Y-%m-%d %H:%M'),
            'command': toolio[1],
            'args': toolio[2],
            'result': toolio[3].children[0].type,
            'output': [line for line in toolio[3].children if line],
            'mission': self.mission,
            'host': self.curr_host,
            'tool': self.tool
            })

    def narrative(self,tree):
        narr = tree.children
        self.chrono_logs.append({
            'datetime': datetime.strptime(narr[0],'%Y-%m-%d %H:%M'),
            'narrative': narr[2],
            'mission': self.mission,
            'host': self.curr_host,
            'tool': self.tool
        })

with open(Path(__file__).parent / 'msnlog.lark', 'r', encoding='utf8') as grammar:
    parser = Lark(grammar,
                  parser='lalr',
                  lexer='contextual',
                  postlex=TreeIndenter(),
                  debug = False,
                  cache = str(Path(__file__).parent)
                  )

diagnostics = []
max_problems = 100

def recover(err:UnexpectedInput) -> bool:
    """Function used during parsing to attempt the on_error recovery. Currently just grabs the
    first expected token type and generates a dummy one to attempt to be able to continue parsing

    Args:
        err (UnexpectedInput): _description_

    Returns:
        bool: _description_
    """
    global diagnostics, max_problems

    if len(diagnostics) >= max_problems:
        return False
    # create a diagnostic
    message = f'Parsing picked this token:\n{err.token.type}:"{err.token.value}"\nExpected 1 of these tokens (incl. regex for reference):\n'
    for name in list(err.accepts):
        if name in ['_INDENT', '_DEDENT']:
            message = f'{message} Unexpected INDENT OR DEDENT\n'
        else:
            message = f'{message}\
{err.interactive_parser.lexer_thread.lexer.lexer.root_lexer.terminals_by_name[name].name} \
{str(err.interactive_parser.lexer_thread.lexer.lexer.root_lexer.terminals_by_name[name].pattern)}\n'
    # edge case where token has no location info, just use last char of last token
    if err.token.line is None:
        range=lsp.Range(
                start=lsp.Position(line=err.interactive_parser.parser_state.value_stack[-1].end_line-1, character=err.interactive_parser.parser_state.value_stack[-1].end_column),
                end=lsp.Position(line=err.interactive_parser.parser_state.value_stack[-1].end_line-1, character=err.interactive_parser.parser_state.value_stack[-1].end_column)
            )
    else:
        range=lsp.Range(
                start=lsp.Position(line=err.token.line-1, character=err.token.column),
                end=lsp.Position(line=err.token.end_line-1, character=err.token.end_column)
            )
    diagnostics.append(
        lsp.Diagnostic(
            range=range,
            severity=lsp.DiagnosticSeverity.Error,
            message=message
        )
    )
    # attempt to feed a dummy token of acceptable type so parsing can continue
    err.interactive_parser.feed_token(Token(list(err.accepts)[0], 'BADBADBAD'))
    return True

def parse_log(doc:str, max_problems_count:int):
    """Parse log content and return an object that includes 

    Args:
        doc (str): The text of the document to parse

    Returns:
        ParseTree: The parse results with a diagnostics property added
    """
    global diagnostics, max_problems
    max_problems = max_problems_count
    # clear the diagnostics every run
    diagnostics = []
    try:
        result = parser.parse(doc, on_error=recover)
    # except (UnexpectedInput, UnexpectedCharacters, UnexpectedEOF, UnexpectedToken):
    except UnexpectedToken as err:
        result = ParseTree(data='', children=[])        
        
    setattr(result, 'diagnostics', diagnostics)

    return result


def get_artifacts(tree: ParseTree):
    """Get the artifacts from a parsed msnlog and create a list of each

    Args:
        tree (ParseTree): The parsed tree of the document from which to grab artifacts

    Returns:
        list: A list of dicts, each dict containing the data for a single artifact
    """
    artifactor = ArtifactGetter()
    artifactor.visit_topdown(tree)
    return artifactor.artifacts


def get_chrono_logs(tree: ParseTree):
    """Get the list of all logs from a parsed msnlog, sorted by the date/time of each entry

    Args:
        tree (ParseTree): The parsed tree of the document from which to grab artifacts

    Returns:
        list: A list of dicts, each dict containing the data for a single log entry, of the format:
            'datetime': 
            'command': 
            'args': 
            'result': 
            'output': ['output_lines']+
            'mission':
                'name':
                'operators':
            'host': 
                'fqdn':
                'ipv4':
                'mac':
            'tool': 
                'type':
                'id':
                'proc_id':
                'proc_name':
                'proc_user':
    """
    chrono = ChronoLogger()
    chrono.visit_topdown(tree)
    logs = sorted(chrono.chrono_logs, key=lambda x:x['datetime'])
    return logs