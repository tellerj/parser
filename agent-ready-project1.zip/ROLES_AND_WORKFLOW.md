# Roles, Responsibilities, and Data Flow

Source: `Project 1 - Mission Logging SOP (CAO 20250611) --signed.pdf`

## Organizational Roles

### Operator
- Executes commands on target systems during Red Team missions
- Maintains their own operator log (`.msn` file) in real time
- Records all required data into the Beacon Log by end of duty day
- Resolves all VSCode errors by end of duty day
- **Relevance to script**: The operator log is the **primary input** to the metadata script

### Technical Lead (TL)
- Creates and maintains the mission kit file structure
- Populates and maintains: TL Daily Log (TLL), Artifact Log, Beacon Log
- Designated by 57 IAS/DO for each mission
- Reviews operator logs for completeness
- **Relevance to script**: TL is likely the person who runs the metadata script to generate output for White Cell

### Team Chief (TC)
- Maintains the Master Station Log (MSL) on NIPR (always UNCLASSIFIED)
- Signs the Attestation Memo
- **Relevance to script**: TC data (MSL) is not directly parsed by the script

### 57 IAS/DO (Director of Operations)
- Archives all mission data
- Signs the Attestation Memo
- Stores Attestation Memo on NIPR
- **Relevance to script**: Receives final archived outputs

### 57 IAS/DOK (Weapons and Tactics)
- Updates logging templates and SOP
- **Relevance to script**: Defines the format the script must parse

### 57 IAS/DOX (Infrastructure)
- Maintains VSCode and vscode-msnlog extension
- Builds the mission kit
- **Relevance to script**: Would likely deploy the metadata script onto mission kits

### 57 IAS/DOT (Training)
- Incorporates mission data logging into training programs (MQT, TL, TC)

## Data Flow During a Mission

```
┌─────────────────────────────────────────────────────────────┐
│                     DURING MISSION                          │
│                                                             │
│  Operator ──writes──> Operator Log (.msn)                   │
│      │                    │                                  │
│      └──records──> Beacon Log (shared spreadsheet)          │
│                                                             │
│  TL ──extracts from operator logs──> Artifact Log (.csv)    │
│  TL ──writes──> TL Daily Log (.txt)                         │
│                                                             │
│  TC ──writes──> Master Station Log (NIPR, UNCLASSIFIED)     │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│                  POST-MISSION (where this script fits)      │
│                                                             │
│  Operator Logs (.msn)                                       │
│       │                                                     │
│       ▼                                                     │
│  ┌──────────────────────────────┐                           │
│  │  METADATA SCRIPT (Project 1) │                           │
│  │                              │                           │
│  │  Inputs:                     │                           │
│  │  - Operator .msn files       │                           │
│  │  - T-Code lookup table       │                           │
│  │                              │                           │
│  │  Processing:                 │                           │
│  │  1. Parse each .msn file     │                           │
│  │  2. Extract command metadata │                           │
│  │  3. Map commands to T-Codes  │                           │
│  │  4. Flag unmatched commands  │                           │
│  │  5. Flag Critical Path items │                           │
│  │  6. Merge & time-sort        │                           │
│  │                              │                           │
│  │  Outputs:                    │                           │
│  │  - Per-operator .xlsx        │                           │
│  │  - Master merged .xlsx       │                           │
│  └──────────────────────────────┘                           │
│       │                                                     │
│       ▼                                                     │
│  White Cell / Blue Assessors (receive master spreadsheet)   │
│       │                                                     │
│       ▼                                                     │
│  Dashboard one-slider (metadata feeds top-left quadrant)    │
└─────────────────────────────────────────────────────────────┘
```

## Post-Mission Data Handling

### Sanitization
- TC and TL manually review and sanitize all operator logs
- All hashes, passwords, and credentials are replaced with `XXXXXXXXXX` (10 Xs)
- Sanitized logs are zipped and archived per 57 IAS/DO procedures
- **Script timing**: The metadata script should run **before** sanitization if it needs to parse credential-related commands, or **after** if only metadata (timestamps, T-Codes, IPs) is needed

### Archive
- Mission data stored for 3 years
- TL and TC prepare data for transfer to 57 IAS/DO
- Archived to NAS in Building 215
- **Archived items**: Operator logs, Artifact Logs (CSV), Beacon Logs, TLLs
- **NOT archived**: Operator plans

### Attestation
- After data delivery, TL, TC, and 57 IAS/DO sign an Attestation Memo
- Stored on NIPR

## Mission Kit File Structure

The TL creates this tree under the operation identifier before execution:

```
MissionData/
├── tools/                              # Red team tools
├── implants/                           # Beacon/implant files
├── cna/                                # Cobalt Strike Aggressor scripts
├── obsidian/                           # Obsidian notes (if used)
├── belfry/                             # (Unknown purpose - likely CB Strike related)
├── plans/
│   └── <operation_identifier>/
│       └── <plan>.md                   # Mission plans (NOT archived)
├── logs/
│   └── <operation_identifier>/
│       └── Daily_Logs/
│           └── YYYYMMDD/
│               ├── Down/               # Files downloaded FROM target hosts
│               │   └── <hostname_IP>/
│               ├── Log/                # Operator logs and TL daily logs
│               │   ├── YYYYMMDD <Operator>.msn
│               │   └── YYYYMMDD_TL_<Last Name>.csv
│               ├── Shell/              # Long command output files
│               │   └── <hostname_IP>/
│               │       └── <timestamp> <tool_name><optional>.file
│               ├── Up/                 # Files uploaded TO target hosts
│               ├── Operator_Logs/      # Symbolic links to daily operator logs
│               │   └── <symlink>.lnk
│               └── TechLead/           # Symbolic links to TL daily logs
│                   └── <symlink>.lnk
├── Artifacts.csv                       # Master artifact log (entire mission)
└── Beacons.csv                         # Master beacon log (entire mission)
```
