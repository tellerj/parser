# Script Requirements

Source: `Project 1 - Capability Request.docx`

## Core Requirements

### REQ-1: Parse Operator Logs
Script can parse standard operator surveys, beacon indents, etc. and output the required metadata from a properly formatted Operator log.

- Input: `.msn` text files formatted per the Mission Logging SOP (see `LOG_FORMAT_SPEC.md`)
- The parser must handle: mission metadata, scheme of maneuver, host headers, tool headers, command input lines, command output lines (with status symbols), artifact headers, comments, and deviation entries.

### REQ-2: Pre-Generated T-Code Mappings
Script will have a pre-generated list of mappings of survey commands and BOFs to T-Codes.

- Source data: `T_CODE_LOOKUP.json` (derived from the T-Code Lookup Tables spreadsheet)
- 144 command/tool-to-T-Code mappings provided
- 16 T-Code family categories defined
- Some commands are "User-Defined" meaning they can map to multiple T-Code families depending on context

### REQ-3: Manual Adjustment Fallback
Script will produce an Excel spreadsheet on failure for 2-3 minutes of manual adjustments by Operators for any commands not matching a pre-generated mapping list to a T-Code.

- When a command cannot be auto-mapped, the script must still output a row for it in the spreadsheet
- The row should be flagged/highlighted for manual review
- Operators should be able to fill in the T-Code manually in the Excel output

### REQ-4: Combine Multiple Outputs
Script will combine multiple Excel spreadsheet outputs into a single copy, time-sorted, master spreadsheet.

- Multiple operator logs from the same mission must merge into one master spreadsheet
- Sorting key: timestamp (ZULU)
- The master spreadsheet aggregates data across all operators for the mission

### REQ-5: Redact Specific Commands
Script will NOT output the specific BOF, PowerShell Script, or other command executed into the spreadsheet unless flagged for manual review (see REQ-3).

- The output protects Red Team TTPs by omitting the actual command text
- Only metadata (timestamp, T-Code, target, etc.) appears in the output
- Exception: unmatched commands (REQ-3) may show the command for manual T-Code assignment

### REQ-6: Validate Endpoint Fields
The "Endpoint Executed From" and "Endpoint Executed On" sections will assume a valid IPv4, IPv6, or device hostname syntactically.

- These fields should be extracted from host headers and tool headers in the operator log
- Validation: must match IPv4, IPv6, or hostname patterns

### REQ-7: Flag Critical Path
Script will flag any Lateral Movement or Persistence command as "Critical Path: Y".

- T-Code families to flag:
  - `TA0008` — Lateral Movement
  - `TA0003` — Persistence
- All other commands: `Critical Path: N`

## Extra Credit Requirements

### REQ-EC-1: Suggest T-Codes
Script will suggest T-Codes for a given command if it is unable to match it to a pre-generated mapping list.

- Could use fuzzy matching, keyword analysis, or LLM-based suggestion

### REQ-EC-2: Branded Header
Script will output a 57 IAS Logo into the top of the Excel Spreadsheet alongside a Mission Date.

- Logo file not provided (would need to be sourced separately)

## Input/Output Summary

```
INPUT:  One or more .msn operator log files (plain text, SOP-formatted)
        T-Code lookup table (pre-loaded in script)

OUTPUT: Per-operator Excel spreadsheet (with unmatched rows flagged)
        Combined master Excel spreadsheet (time-sorted across all operators)
        Non-hidden columns from "Master Set & Scoring" tab format
```

## Acceptance Criteria

1. Given a properly formatted operator log, the script produces a complete Excel spreadsheet with all parseable actions mapped to T-Codes.
2. Unmatched commands are flagged for manual review, not silently dropped.
3. Multiple operator outputs merge into a single time-sorted master sheet.
4. No specific command/BOF/script text appears in the output (unless flagged per REQ-3).
5. Lateral Movement and Persistence actions are flagged as Critical Path.
6. Endpoint fields contain syntactically valid IPv4/IPv6/hostname values.
